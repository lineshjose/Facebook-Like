<?php /*	Template Name:Footer	
URI: http://linesh.com/
Description:  Feature-packed theme with a solid design, built-in widgets and a intuitive theme settings interface... Designed by <a href="http://linesh.com/">Linesh Jose</a>.	
Version: 15.5	
Author: Linesh Jose 	
Author URI: http://linesh.com/	
roTags: light, white,two-columns, Flexible-width, right-sidebar, left-sidebar, theme-options, threaded-comments, translation-ready, custom-header		http://linesh.com/	Both the design and code are released under GPL.	http://www.opensource.org/licenses/gpl-license.php
*/?>

<div class="clearboth"></div>
</div>
<!-- end content -->
<div id="footer">
  <p> <a href="<?php bloginfo('url') ?>">
    <?php bloginfo('name'); ?>
    </a> &copy; <?php echo date('Y'); ?> . 	Powered by <a href="http://adfoc.us/28737555627001">WordPress</a>..	Theme by <a href="http://linesh.com/">Linesh Jose</a>.</p>
  <?php wp_footer(); ?>
</div>
<!-- end footer --><!-- end rightbar -->
</td>
</tr>
</table>
</div>
<!-- end container -->

</body></html>